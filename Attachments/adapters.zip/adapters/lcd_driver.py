import machine
from . import lcd_api
LcdApi = lcd_api.LcdApi
from . import i2c_lcd
I2cLcd = i2c_lcd.I2cLcd

class DisplayDriver:
    def __init__(self, sclp, sdap):
        addr = 0x27
        tr = 2
        tc = 16

        i2c = machine.I2C(scl=machine.Pin(sclp), sda=machine.Pin(sdap), freq=10000, id=0)

        self.lcd = I2cLcd(i2c,addr,tr,tc)
        
    def getDisplay(self):
        return self.lcd
    
