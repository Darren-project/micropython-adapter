import machine

class ServoDriver:
    def __init__(self,spin):
        self.servo = machine.PWM(machine.Pin(spin))
        self.servo.freq(50)
        
    def move(self,angle):
        cycle = angle / 18 + 2
        duty = cycle * 65535 / 100
        self.servo.duty_u16(int(duty))