import machine

class MotorDriver:
    def __init__(self, p1,p2,p3,p4):
         self.M1A = machine.PWM(machine.Pin(p1))
         self.M1B = machine.PWM(machine.Pin(p2))
         self.M2A = machine.PWM(machine.Pin(p3))
         self.M2B = machine.PWM(machine.Pin(p4))

         for i in [self.M1A, self.M1B, self.M2A, self.M2B]:
            i.freq(50)
    
    def control(self, m1a,m1b,m2a,m2b):
        for i in [{"duty": self.M1A, "para": m1a}, {"duty": self.M1B, "para": m1b}, {"duty": self.M2A, "para": m2a}, {"duty": self.M2B, "para": m2b}]:
            i["duty"].duty_u16(i["para"])
